# Livelook

TypeScript React + Vite SPA demo project (mock payments).

## Run locally
npm install
npm run dev
npm run test
