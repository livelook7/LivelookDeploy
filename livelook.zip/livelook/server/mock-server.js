// Optional mock server for demos. This is harmless and not required for mock payments in frontend.
import express from 'express'
const app = express()
app.use(express.json())
app.get('/health', (req, res) => res.json({ ok: true }))
app.listen(3000, ()=>console.log('mock server running on 3000'))
