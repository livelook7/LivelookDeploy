import { PRODUCTS } from '../src/data/products'

test('Products length is 20', () => {
  expect(PRODUCTS.length).toBe(20)
})
